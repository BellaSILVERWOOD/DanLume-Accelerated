//! Canvas（eLearning）接口：课程 / 作业 / 文件 / 下载（对应旧版 `elearning.py`）。
//!
//! 鉴权与教务同理，需要"第二跳"：ID 会话 → `elearning.fudan.edu.cn` 服务会话，
//! 之后按 Canvas REST API 取数据（旧版用的就是这几个端点）。
use serde_json::{json, Value};

use crate::store::Store;
use crate::uis;

pub const BASE: &str = "https://elearning.fudan.edu.cn";
pub const COURSES: &str =
    "/api/v1/courses?enrollment_state=active&per_page=100";
pub const ASSIGNMENTS: &str =
    "/api/v1/courses/{cid}/assignments?per_page=100";
pub const FILES: &str =
    "/api/v1/courses/{cid}/files?per_page=100&sort=created_at&order=desc";

fn agent() -> ureq::Agent {
    ureq::AgentBuilder::new()
        .timeout(std::time::Duration::from_secs(30))
        .redirects(5)
        .user_agent(
            "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 \
             (KHTML, like Gecko) Chrome/120.0 Safari/537.36",
        )
        .build()
}

/// 建立（或复用）Canvas 会话：先请求首页走完整 SSO
pub fn ensure_session(store: &Store) -> Result<uis::Jar, String> {
    let (final_url, jar) = uis::visit_with_session(store, BASE)?;
    if final_url.contains("id.fudan.edu.cn") {
        return Err(format!(
            "会话对 Canvas 无效（被重定向到统一身份认证）：先在「打开登录窗口」里登录，再点「抓取会话」。落地地址：{final_url}"
        ));
    }
    Ok(jar)
}

fn get_json(jar: &uis::Jar, path: &str) -> Result<Value, String> {
    let url = format!("{BASE}{path}");
    let response = agent()
        .get(&url)
        .set("Cookie", &jar.to_header())
        .set("Accept", "application/json")
        .call()
        .map_err(|exc| format!("请求 {path} 失败：{exc}"))?;
    let text = response
        .into_string()
        .map_err(|exc| format!("{path} 内容读不出来：{exc}"))?;
    serde_json::from_str(&text).map_err(|_| {
        let head: String = text.chars().take(160).collect();
        format!("{path} 返回的不是 JSON（可能没登录）：{head}")
    })
}

pub fn courses(store: &Store, keyword: &str) -> Result<Vec<Value>, String> {
    let jar = ensure_session(store)?;
    let value = get_json(&jar, COURSES)?;
    let rows = value.as_array().cloned().unwrap_or_default();
    let filtered: Vec<Value> = rows
        .into_iter()
        .filter(|one| {
            keyword.is_empty()
                || one
                    .get("name")
                    .and_then(|value| value.as_str())
                    .map(|name| name.contains(keyword))
                    .unwrap_or(false)
        })
        .map(|one| {
            json!({
                "id": one.get("id").cloned().unwrap_or(json!(0)),
                "name": one.get("name").and_then(|v| v.as_str()).unwrap_or(""),
                "course_code": one.get("course_code").and_then(|v| v.as_str()).unwrap_or(""),
            })
        })
        .collect();
    Ok(filtered)
}

pub fn assignments(store: &Store, course_id: &str) -> Result<Vec<Value>, String> {
    let jar = ensure_session(store)?;
    let value = get_json(&jar, &ASSIGNMENTS.replace("{cid}", course_id))?;
    Ok(value.as_array().cloned().unwrap_or_default())
}

pub fn files(store: &Store, course_id: &str) -> Result<Vec<Value>, String> {
    let jar = ensure_session(store)?;
    let value = get_json(&jar, &FILES.replace("{cid}", course_id))?;
    Ok(value.as_array().cloned().unwrap_or_default())
}

/// 诊断：课程接口通不通、返回几条
pub fn probe(store: &Store) -> Value {
    match courses(store, "") {
        Ok(rows) => {
            // 记下第一门课，供「下载首门课程文件」按钮用
            if let Some(first) = rows.first() {
                if let Some(id) = first.get("id").and_then(|one| one.as_i64()) {
                    let _ = store.set_setting("canvas_last_course", &id.to_string());
                }
                if let Some(name) = first.get("name").and_then(|one| one.as_str()) {
                    let _ = store.set_setting("canvas_last_course_name", name);
                }
            }
            json!({
                "ok": true,
                "courses": rows.len(),
                "names": rows.iter().take(5).map(|one| {
                    one.get("name").and_then(|v| v.as_str()).unwrap_or("").to_string()
                }).collect::<Vec<_>>(),
            })
        }
        Err(exc) => json!({ "ok": false, "error": exc }),
    }
}

/// 下载某门课的文件到下载目录（重名跳过），返回 saved/skipped/failed
pub fn download_course(store: &Store, course_id: &str, limit: usize) -> Value {
    let jar = match ensure_session(store) {
        Ok(jar) => jar,
        Err(exc) => return json!({ "ok": false, "error": exc }),
    };
    let target = {
        let text = store.setting("dir_downloads").unwrap_or_default();
        if text.trim().is_empty() {
            crate::paths::data_dir().join("elearning")
        } else {
            std::path::PathBuf::from(text.trim())
        }
    };
    let _ = std::fs::create_dir_all(&target);
    let list = match files(store, course_id) {
        Ok(rows) => rows,
        Err(exc) => return json!({ "ok": false, "error": exc }),
    };
    let mut saved: Vec<String> = Vec::new();
    let mut failed: Vec<String> = Vec::new();
    let mut skipped = 0usize;
    for file in list.into_iter().take(limit.max(1)) {
        let name = file
            .get("display_name")
            .and_then(|v| v.as_str())
            .or_else(|| file.get("filename").and_then(|v| v.as_str()))
            .unwrap_or("file");
        let url = file
            .get("url")
            .and_then(|v| v.as_str())
            .or_else(|| file.get("preview_url").and_then(|v| v.as_str()))
            .unwrap_or("");
        if url.is_empty() {
            failed.push(name.to_string());
            continue;
        }
        let clean: String = name
            .chars()
            .map(|ch| if "\\/:*?\"<>|".contains(ch) { '-' } else { ch })
            .collect();
        let path = target.join(&clean);
        if path.exists() {
            skipped += 1;
            continue;
        }
        let response = agent().get(url).set("Cookie", &jar.to_header()).call();
        match response {
            Ok(res) => {
                let mut bytes: Vec<u8> = Vec::new();
                use std::io::Read;
                if res.into_reader().read_to_end(&mut bytes).is_ok()
                    && std::fs::write(&path, &bytes).is_ok()
                {
                    saved.push(clean);
                } else {
                    failed.push(clean);
                }
            }
            Err(_) => failed.push(clean),
        }
    }
    json!({
        "ok": true,
        "saved": saved.len(),
        "skipped": skipped,
        "failed": failed.len(),
        "files": saved,
        "target": target.display().to_string(),
    })
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn endpoints_match_python_version() {
        assert_eq!(COURSES, "/api/v1/courses?enrollment_state=active&per_page=100");
        assert!(ASSIGNMENTS.contains("{cid}"));
        assert!(FILES.contains("sort=created_at"));
        assert_eq!(
            BASE,
            "https://elearning.fudan.edu.cn"
        );
    }

    /// 真联网：cargo test --lib -- --ignored --nocapture canvas_real_probe
    #[test]
    #[ignore]
    fn canvas_real_probe() {
        std::env::set_var(
            "LUMINA_DATA_DIR",
            r"E:\FIles\Lena‘s Files\Work\znw\Agent\data",
        );
        let store = Store::open().expect("打不开数据库");
        println!("Canvas 诊断：{}", probe(&store));
    }
}
