<script setup lang="ts">
// 通知：教务 / eHall 通知流（对应旧版 page_notices.py）
import { computed, onMounted, ref } from "vue";
import SoftButton from "../components/SoftButton.vue";
import Pill from "../components/Pill.vue";
import {
  markAllNoticesRead,
  markNoticeRead,
  noticeList,
  openPath,
  refreshNotices,
  type NoticeItem,
} from "../api";

const items = ref<NoticeItem[]>([]);
const unread = ref(0);
const onlyUnread = ref(false);
const busy = ref(false);
const message = ref("");

const countText = computed(
  () => `${items.value.length} 条${unread.value ? ` · ${unread.value} 条未读` : ""}`,
);

async function load() {
  const result = await noticeList(onlyUnread.value);
  items.value = result.items;
  unread.value = result.unread;
}

async function refresh() {
  busy.value = true;
  try {
    const result = await refreshNotices();
    message.value = result.ok
      ? `抓取完成：新增 ${result.added} 条`
      : result.error || "抓取失败";
    await load();
  } finally {
    busy.value = false;
  }
}

async function readAll() {
  const count = await markAllNoticesRead();
  message.value = `已把 ${count} 条标记为已读`;
  await load();
}

async function open(item: NoticeItem) {
  if (!item.read_at) {
    await markNoticeRead(item.id);
    await load();
  }
  if (item.url) {
    // 通知原文在 eHall 里；这里先用系统浏览器打开（内嵌 eHall 页在第四阶段）
    window.open(item.url, "_blank");
  }
}

onMounted(load);
</script>

<template>
  <div class="page">
    <div class="page-head">
      <div class="titles">
        <h1 class="h1">通知</h1>
        <div class="muted">教务、活动等通知汇总（日程不在此处）</div>
      </div>
      <div class="spacer" />
      <Pill :text="countText" :font-size="11.5" />
      <SoftButton :height="32" :font-size="12.5" glyph="CHECK" @click="readAll">
        全部标为已读
      </SoftButton>
      <SoftButton
        variant="primary"
        :height="32"
        :font-size="12.5"
        glyph="REFRESH"
        :disabled="busy"
        @click="refresh"
      >
        {{ busy ? "抓取中…" : "刷新抓取" }}
      </SoftButton>
    </div>

    <div class="filter">
      <label>
        <input v-model="onlyUnread" type="checkbox" @change="load" />
        只看未读
      </label>
      <span v-if="message" class="muted">{{ message }}</span>
    </div>

    <div class="list">
      <div v-if="!items.length" class="empty">
        还没有抓到通知，点右上角「刷新抓取」（先在 设置 → 仪表板 里填通知来源地址）
      </div>
      <button
        v-for="item in items"
        :key="item.id"
        class="row"
        :class="{ unread: !item.read_at }"
        @click="open(item)"
      >
        <span class="dot">●</span>
        <span class="text">
          <span class="title">{{ item.title }}</span>
          <span class="meta">
            {{ item.source === "notice" ? "通知" : item.source }} ·
            {{ item.read_at ? `已读 ${item.read_at.slice(5, 16)}` : "未读" }}
          </span>
        </span>
        <span class="date">{{ (item.published_at || item.fetched_at || "").slice(0, 10) }}</span>
      </button>
    </div>
  </div>
</template>

<style scoped>
.page {
  display: flex;
  flex-direction: column;
  gap: 10px;
  height: 100%;
}
.filter {
  display: flex;
  align-items: center;
  gap: 12px;
  font-size: 12.5px;
  color: var(--muted);
}
.filter label {
  display: inline-flex;
  align-items: center;
  gap: 6px;
}
.list {
  flex: 1;
  overflow-y: auto;
  display: flex;
  flex-direction: column;
  gap: 4px;
  padding-right: 4px;
}
.row {
  display: flex;
  align-items: flex-start;
  gap: 10px;
  padding: 10px 13px;
  border-radius: var(--radius-card);
  border: 1px solid var(--border-soft);
  background: var(--card);
  text-align: left;
  font-family: inherit;
  cursor: pointer;
}
.row:hover {
  background: var(--card-hover);
}
.dot {
  font-size: 7px;
  line-height: 2;
  color: var(--faint);
}
.row.unread .dot {
  color: var(--accent);
}
.text {
  flex: 1;
  display: flex;
  flex-direction: column;
  gap: 3px;
  min-width: 0;
}
.title {
  font-size: 14px;
  color: var(--text);
  overflow-wrap: anywhere;
}
.row.unread .title {
  font-weight: 600;
}
.meta {
  font-size: 11.5px;
  color: var(--muted);
}
.date {
  font-size: 12px;
  color: var(--muted);
  white-space: nowrap;
}
.empty {
  font-size: 12.5px;
  color: var(--muted);
  line-height: 1.7;
  padding: 8px 2px;
}
/* 列表行一律左对齐（button 默认居中） */
.list .row,
.list .row > span {
  text-align: left;
}
</style>
