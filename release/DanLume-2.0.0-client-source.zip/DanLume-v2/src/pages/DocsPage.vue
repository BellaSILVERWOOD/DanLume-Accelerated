﻿<script setup lang="ts">
// 文档：左边目录列表、右边预览（对应旧版 page_docs.py）
import { computed, onMounted, ref } from "vue";
import SoftButton from "../components/SoftButton.vue";
import IconBadge from "../components/IconBadge.vue";
import PdfViewer from "../components/PdfViewer.vue";
import {
  defaultDocsDir,
  listDir,
  openPath,
  pickFiles,
  readTextFile,
  revealPath,
  settingsAll,
  settingsSave,
  type DocEntry,
} from "../api";

const dir = ref("");
const entries = ref<DocEntry[]>([]);
const selected = ref<DocEntry | null>(null);
const preview = ref("");
const message = ref("");
const busy = ref(false);
const shortcuts = ref<{ label: string; path: string }[]>([]);

function human(size: number): string {
  if (size >= 1024 * 1024) return `${(size / 1024 / 1024).toFixed(1)} MB`;
  if (size >= 1024) return `${Math.round(size / 1024)} KB`;
  return `${size} B`;
}

function badgeTone(kind: string): string {
  if (kind === "PDF") return "rose";
  if (kind === "Word") return "sky";
  if (kind === "PPT") return "amber";
  if (kind === "Excel") return "teal";
  if (kind === "图片") return "violet";
  return "teal";
}

const parentPath = computed(() => {
  const parts = dir.value.replace(/\\/g, "/").split("/");
  parts.pop();
  return parts.join("\\");
});

const isPdf = computed(() => {
  const one = selected.value;
  if (!one) return false;
  return one.kind === "PDF" || one.name.toLowerCase().endsWith(".pdf");
});

async function openDir(path: string) {
  busy.value = true;
  try {
    const result = await listDir(path);
    dir.value = result.dir || path;
    entries.value = result.entries || [];
    message.value = "";
    selected.value = null;
    preview.value = "";
  } catch (err) {
    message.value = String(err);
  } finally {
    busy.value = false;
  }
}

async function choose(entry: DocEntry) {
  if (entry.is_dir) {
    await openDir(entry.path);
    return;
  }
  selected.value = entry;
  // 旧版 last_doc：记住最后看的那个文件，下次进来直接回到它
  void settingsSave({ last_doc: entry.path });
  preview.value = "";
  if (entry.kind === "PDF") return;
  if (["文本", "文件"].includes(entry.kind) || entry.kind === "") {
    try {
      if (entry.kind === "文本") {
        preview.value = await readTextFile(entry.path);
      } else {
        preview.value = "";
      }
    } catch (err) {
      preview.value = String(err);
    }
  }
}

async function pickFile() {
  // 原生「选文件」对话框：选中就用系统程序打开
  const picked = await pickFiles();
  if (!picked.length) return;
  await openPath(picked[0]);
}

onMounted(async () => {
  const info = await defaultDocsDir();
  shortcuts.value = [
    { label: "作业下载目录", path: info.downloads },
    { label: "数据目录", path: info.data },
  ];
  // 先试着回到上次看的文件（旧版 last_doc）
  let restored = false;
  try {
    const all = await settingsAll();
    const last = (all.values || {})["last_doc"] || "";
    if (last) {
      const slash = Math.max(last.lastIndexOf("\\"), last.lastIndexOf("/"));
      const dir = slash > 0 ? last.slice(0, slash) : "";
      if (dir) {
        await openDir(dir);
        const hit = entries.value.find((one) => one.path === last);
        if (hit) {
          await choose(hit);
          restored = true;
        }
      }
    }
  } catch {
    // 读不到就按默认目录打开
  }
  if (!restored) await openDir(info.downloads || info.data);
});
</script>

<template>
  <div class="page">
    <div class="page-head">
      <div class="titles">
        <h1 class="h1">文档</h1>
        <div class="muted">PDF / Word / PPT / Excel 文件都能直接看</div>
      </div>
      <div class="spacer" />
      <SoftButton :height="32" :font-size="12.5" glyph="FOLDER" @click="pickFile">
        打开文件
      </SoftButton>
      <SoftButton :height="32" :font-size="12.5" glyph="FOLDER" @click="openPath(dir)">
        打开下载目录
      </SoftButton>
      <SoftButton :height="32" :font-size="12.5" @click="selected && openPath(selected.path)">
        用系统程序打开
      </SoftButton>
      <SoftButton :height="32" :font-size="12.5" glyph="MAXIMIZE">全屏</SoftButton>
    </div>

    <div class="body">
      <div class="side">
        <div class="side-title">分类 / 最近目录</div>
        <button
          v-for="item in shortcuts"
          :key="item.path"
          class="side-row"
          @click="openDir(item.path)"
        >
          <span class="name">{{ item.label }}</span>
          <span class="path">{{ item.path }}</span>
        </button>
        <div class="side-foot">
          <div class="path-full">{{ dir }}</div>
        </div>
      </div>

      <div class="list">
        <div class="list-head">
          <button class="up" :disabled="!parentPath" @click="openDir(parentPath)">
            ↑ 上一层
          </button>
          <span class="spacer" />
          <span class="tiny">{{ entries.length }} 项{{ busy ? " · 读取中…" : "" }}</span>
        </div>
        <div class="rows">
          <button
            v-for="entry in entries"
            :key="entry.path"
            class="row"
            :class="{ on: selected?.path === entry.path }"
            @click="choose(entry)"
            @dblclick="openPath(entry.path)"
          >
            <IconBadge
              :glyph="entry.is_dir ? 'FOLDER' : 'DOCUMENT'"
              :tone="entry.is_dir ? 'amber' : badgeTone(entry.kind)"
              :size="24"
            />
            <span class="name">{{ entry.name }}</span>
            <span class="kind">{{ entry.kind }}</span>
            <span class="size">{{ entry.is_dir ? "" : human(entry.size) }}</span>
            <span class="date">{{ entry.modified.slice(5) }}</span>
          </button>
          <div v-if="!entries.length" class="empty">
            {{ message || "这个目录是空的" }}
          </div>
        </div>
      </div>

      <div class="preview">
        <div class="preview-head">
          <span class="name">{{ selected ? selected.name : "预览" }}</span>
          <span class="spacer" />
          <SoftButton
            v-if="selected"
            :height="26"
            :font-size="11.5"
            @click="revealPath(selected.path)"
          >
            在资源管理器里显示
          </SoftButton>
        </div>
        <div class="preview-body">
          <template v-if="selected">
            <PdfViewer
              v-if="isPdf"
              class="pdf-host"
              :path="selected.path"
              mode="multi"
            />
            <pre v-else-if="preview" class="text">{{ preview }}</pre>
            <div v-else class="hint">
              <IconBadge glyph="DOCUMENT" :tone="badgeTone(selected.kind)" :size="40" />
              <div class="kind-big">{{ selected.kind }}</div>
              <div class="muted">
                {{ selected.name }} · {{ human(selected.size) }} ·
                {{ selected.modified }}
              </div>
              <div class="muted">
                {{ selected.kind === "PDF" ? "PDF 读取失败，可以交给系统默认程序打开" : "这类文件交给你自己的系统程序打开" }}
              </div>
              <SoftButton :height="30" :font-size="12.5" @click="openPath(selected.path)">
                用系统程序打开
              </SoftButton>
            </div>
          </template>
          <div v-else class="hint muted">选左边一个文件就能预览</div>
        </div>
      </div>
    </div>
  </div>
</template>

<style scoped>
.page {
  display: flex;
  flex-direction: column;
  gap: 12px;
  height: 100%;
}
.body {
  flex: 1;
  display: flex;
  gap: 12px;
  min-height: 0;
}
.side {
  width: 232px;
  flex: none;
  display: flex;
  flex-direction: column;
  gap: 4px;
}
.side-title {
  font-size: 11.5px;
  font-weight: 600;
  color: var(--faint);
  padding: 2px 4px 4px;
}
.side-row {
  display: flex;
  flex-direction: column;
  gap: 2px;
  padding: 8px 10px;
  border: 1px solid var(--border-soft);
  border-radius: 10px;
  background: var(--card);
  text-align: left;
  font-family: inherit;
  cursor: pointer;
}
.side-row:hover {
  background: var(--card-hover);
}
.side-row .name {
  font-size: 13px;
  color: var(--text);
}
.side-row .path,
.path-full {
  font-size: 11px;
  color: var(--muted);
  overflow-wrap: anywhere;
}
.side-foot {
  margin-top: auto;
  padding: 6px 4px;
}
.list {
  flex: 1;
  min-width: 0;
  display: flex;
  flex-direction: column;
  gap: 6px;
}
.list-head {
  display: flex;
  align-items: center;
  gap: 8px;
}
.up {
  height: 24px;
  padding: 0 10px;
  border-radius: 8px;
  border: 1px solid var(--border-soft);
  background: var(--card);
  font-family: inherit;
  font-size: 12px;
  color: var(--text-soft);
  cursor: pointer;
}
.up:disabled {
  opacity: 0.45;
  cursor: default;
}
.rows {
  flex: 1;
  overflow-y: auto;
  display: flex;
  flex-direction: column;
  gap: 2px;
}
.row {
  display: flex;
  align-items: center;
  gap: 9px;
  padding: 7px 9px;
  border-radius: 9px;
  border: 1px solid transparent;
  background: transparent;
  font-family: inherit;
  text-align: left;
  cursor: pointer;
}
.row:hover {
  background: var(--card-hover);
}
.row.on {
  border-color: var(--accent);
  background: color-mix(in srgb, var(--accent) 7%, transparent);
}
.row .name {
  flex: 1;
  min-width: 0;
  font-size: 13px;
  color: var(--text);
  overflow: hidden;
  text-overflow: ellipsis;
  white-space: nowrap;
}
.row .kind,
.row .size,
.row .date {
  font-size: 11.5px;
  color: var(--muted);
  white-space: nowrap;
}
.preview {
  width: 40%;
  min-width: 320px;
  display: flex;
  flex-direction: column;
  gap: 6px;
  background: var(--card);
  border: 1px solid var(--border-soft);
  border-radius: var(--radius-card);
  padding: 12px 14px;
}
.preview-head {
  display: flex;
  align-items: center;
  gap: 8px;
  padding-bottom: 6px;
  border-bottom: 1px solid var(--border-soft);
}
.preview-head .name {
  font-size: 13.5px;
  font-weight: 600;
}
.preview-body {
  flex: 1;
  overflow-y: auto;
  min-height: 0;
  display: flex;
  flex-direction: column;
}
.pdf-host {
  flex: 1;
  min-height: 0;
}
.text {
  margin: 0;
  font-family: var(--font-mono);
  font-size: 12px;
  line-height: 1.65;
  white-space: pre-wrap;
  overflow-wrap: anywhere;
  color: var(--text);
  user-select: text;
}
.hint {
  display: flex;
  flex-direction: column;
  align-items: center;
  gap: 8px;
  padding: 28px 10px;
  text-align: center;
  font-size: 12.5px;
  line-height: 1.7;
}
.kind-big {
  font-size: 15px;
  font-weight: 640;
  color: var(--text-soft);
}
.empty {
  font-size: 12.5px;
  color: var(--muted);
  padding: 8px 4px;
}
.spacer {
  flex: 1;
}
/* 列表行一律左对齐（button 默认居中） */
.rows .row,
.rows .row > span {
  text-align: left;
}
</style>
